package main;

public class Console {
    public void printLine(String line) {
        System.out.println(line);
    }
}
